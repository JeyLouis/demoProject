document.querySelector('#buttonTwo').addEventListener('click', parks);

async function parks(){
try{
  const res = await fetch('http://localhost:4523/api/playgrounds')
  const data = await res.json()

  console.log(data);
}catch(err){
  console.log(err);
}

}










// const apiKey = AIzaSyASSGdDnjFAtZzMUFyQ-k03Sk23SNNDnJg
//
// <script>
//   function initMap(){
//     // var options = {
//     //   zoom:8,
//     //   center:{lat:42.3601, lng:-71.0589}
//     }
//     var map = new  google.maps.Map(document.getElementById('map')options);
//   }
// </script>
// <script async defer
//    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyASSGdDnjFAtZzMUFyQ-k03Sk23SNNDnJg&callback=initMap&libraries=&v=weekly"></script>
//
// for (let i = 0; i < select.length; i++) {
//   select[i].addEventListener('click', () => {
//     console.log("do the fetch for ", select[i].id);
//
//     let url = `https://cors-anywhere.herokuapp.com/https://horoscope-api.herokuapp.com/horoscope/today/${select[i].id}`
//
//     console.log(url);
//     fetch(url)
//       .then(res => res.json())
//       .then(data => {
//         console.log(data);
//
//         let horoscope = document.querySelector('.horscope').innerHTML = data.horoscope;
//         // console.log(data.slip.id)
//         let urlAdvice = `https://api.adviceslip.com/advice`
//         console.log(urlAdvice);
//
//         fetch(urlAdvice)
//           .then(res => res.json())
//           .then(adviceData => {
//             console.log(adviceData);
//             let advice = document.querySelector('.advice').innerHTML = adviceData.slip.advice;
//           })
//       })
//   })
//
// }
