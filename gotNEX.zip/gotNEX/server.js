const express = require('express')
const cors = require('cors')
const app = express()
const PORT = 2000

let playgrounds = {
  'Hunt PlayGround': {
    'Coordinates': `lat:42.2742, long: -71.0969`
  },
  'Harambee PlayGround': {
    'Coordinates': `lat:42.2921, long: -71.0847`
  },
  'Walker PlayGround': {
    'Coordinates': `lat:42.093, long: -72.5848`
  },
  'unknown': {
    'Coordinates': `unknown`
  }
}
app.use(cors())

app.get('/', (request, response) => {
  response.sendFile(__dirname + '/index.html')
})

app.get('/api/playgrounds', (request, response) => {
  response.json(playgrounds)
})

app.listen(PORT, () => {
  console.log(`We playing Ba-sket-BALL!! server running on port ${PORT}`);
})
